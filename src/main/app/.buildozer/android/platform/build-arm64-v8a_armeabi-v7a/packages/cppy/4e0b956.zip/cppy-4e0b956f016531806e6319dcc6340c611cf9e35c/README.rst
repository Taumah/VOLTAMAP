cppy
====

.. image:: https://travis-ci.org/nucleic/cppy.svg?branch=master
    :target: https://travis-ci.org/nucleic/cppy

A small C++ header library which makes it easier to write Python extension
modules. The primary feature is a PyObject smart pointer which automatically
handles reference counting and provides convenience methods for performing
common object operations.
