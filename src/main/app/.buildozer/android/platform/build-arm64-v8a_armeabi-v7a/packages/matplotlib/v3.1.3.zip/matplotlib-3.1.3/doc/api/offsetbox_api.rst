************************
``matplotlib.offsetbox``
************************

.. automodule:: matplotlib.offsetbox
   :members:
   :undoc-members:
   :show-inheritance:
