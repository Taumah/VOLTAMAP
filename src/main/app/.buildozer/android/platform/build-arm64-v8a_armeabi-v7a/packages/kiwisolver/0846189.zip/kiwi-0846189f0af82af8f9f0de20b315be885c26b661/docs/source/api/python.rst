Kiwisolver Python API
=====================

.. automodule:: kiwisolver
    :members:
    :undoc-members:
    :show-inheritance:
