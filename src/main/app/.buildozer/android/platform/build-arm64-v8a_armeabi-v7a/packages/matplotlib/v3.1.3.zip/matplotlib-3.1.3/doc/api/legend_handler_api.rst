*****************************
``matplotlib.legend_handler``
*****************************

.. automodule:: matplotlib.legend_handler
      :members:
      :undoc-members:
