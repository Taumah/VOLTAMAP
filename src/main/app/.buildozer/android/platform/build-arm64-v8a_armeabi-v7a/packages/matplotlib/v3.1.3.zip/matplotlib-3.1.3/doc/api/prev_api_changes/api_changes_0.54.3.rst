
Changes for 0.54.3
==================

.. code-block:: text

  removed the set_default_font / get_default_font scheme from the
  font_manager to unify customization of font defaults with the rest of
  the rc scheme.  See examples/font_properties_demo.py and help(rc) in
  matplotlib.matlab.
